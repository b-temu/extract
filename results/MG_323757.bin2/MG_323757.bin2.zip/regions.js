var recordData = [
 {
  "length": 553035,
  "seq_id": "NODE_1_length_553035_cov_166.184616",
  "regions": []
 },
 {
  "length": 343487,
  "seq_id": "NODE_2_length_343487_cov_138.570308",
  "regions": []
 },
 {
  "length": 317791,
  "seq_id": "NODE_4_length_317791_cov_150.553277",
  "regions": []
 },
 {
  "length": 141248,
  "seq_id": "NODE_6_length_141248_cov_158.414957",
  "regions": []
 },
 {
  "length": 91489,
  "seq_id": "NODE_10_length_91489_cov_176.007043",
  "regions": []
 },
 {
  "length": 39752,
  "seq_id": "NODE_20_length_39752_cov_184.349170",
  "regions": []
 },
 {
  "length": 17190,
  "seq_id": "NODE_42_length_17190_cov_215.424395",
  "regions": []
 },
 {
  "length": 5441,
  "seq_id": "NODE_132_length_5441_cov_3271.825659",
  "regions": []
 },
 {
  "length": 1857,
  "seq_id": "NODE_219_length_1857_cov_418.184240",
  "regions": []
 },
 {
  "length": 1372,
  "seq_id": "NODE_267_length_1372_cov_129.504176",
  "regions": []
 },
 {
  "length": 1371,
  "seq_id": "NODE_268_length_1371_cov_146.617021",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
